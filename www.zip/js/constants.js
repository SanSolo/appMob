angular.module('citizen-engagement')
  .constant('apiUrl', 'https://comem-citizen-engagement-2017g.herokuapp.com/api')
  .constant('mapboxSecret', 'pk.eyJ1IjoiYWxqdW5vZCIsImEiOiJjajBjZ3l1c2kwMDF4MndwOWkxOHhmN2J0In0.EUtWXijmndrFBmImzDfN2Q')



;
